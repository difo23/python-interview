
# Los comentarios en Python inician con 

print("Bienvenidos")

intento= input("Adivina el numero: ")
adivinaIntento = int(intento)

if adivinaIntento == 5:
    print("Tu ganas!")
else:
    print("Tu pierdes!")

print("Game Over!")