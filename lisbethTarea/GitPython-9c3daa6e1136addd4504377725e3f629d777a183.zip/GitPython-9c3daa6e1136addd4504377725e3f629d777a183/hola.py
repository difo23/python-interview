print ("determinarPares")
numero = input("introduce numero: ")
numero = int(numero)
if numero % 2 == 0:
    print("Es par")
else:
    print("Es impar") 